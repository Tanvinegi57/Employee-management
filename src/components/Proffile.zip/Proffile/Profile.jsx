import React, { useState } from "react";
import Button from "react-bootstrap/Button";
import { Container } from "react-bootstrap";
import { AiOutlineLeft } from "react-icons/ai";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import Form from "react-bootstrap/Form";
import "../../pages/Addadmin.css";
const Profile = () => {
  const navigate = useNavigate();
  const [values, setValues] = useState({
    name: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    console.log(`${name}-${value}`);
    setValues({
      ...values,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // setFormErrors(Validate(values));
    if (!name) {
      return toast.error("Please Fill out all the Fields");
    }
  };

  const { name } = values;

  let user = JSON.parse(localStorage.getItem("jwt"));
  return (
    <Container>
      <div className="admin-main">
        <div>
          <AiOutlineLeft fa-lg />
          Profile
        </div>
        <hr />
        <Form onSubmit={handleSubmit}>
          <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
            <Form.Label className="required-FIELD">Name</Form.Label>
            <Form.Control
              type="email"
              placeholder={user.data.user.name}
              name="name"
              value={values.name}
              onChange={handleChange}
            />
          </Form.Group>

          <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
            <Form.Label>Email</Form.Label>
            <Form.Control
              type="email"
              // placeholder={user.data.user.email}
              name="email"
              value={user.data.user.email}
              // onChange={handleChange}
              readOnly
            />
          </Form.Group>
          <Button
            style={{ width: "100%", backgroundColor: "black", color: "white" }}
            type="submit"
          >
            Save
          </Button>
        </Form>
      </div>
    </Container>
  );
};

export default Profile;
